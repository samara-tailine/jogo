#GLOBAL
extends Node

var vidas = 5 #Vidas da nave fase 1
var asteroides = 0
#essa variável é para o player. O valor 0 deixa o player andar e o valor 1 para o player
var onion = 0 
var vidasPlayer = 3 #Vidas do player demais fases
