#GAME OVER
extends Control

func _on_try_again_pressed() -> void:
	Global.vidasPlayer = 3
	get_tree().change_scene_to_file("res://Scenes/fase_3.tscn") #volta para a 1ª fase

func _on_sair_pressed() -> void:
	get_tree().quit() #sai do jogo
