extends Node2D

var asteroide = preload("res://Scenes/asteroide.tscn")

func _ready() -> void:
	pass

func _process(delta: float) -> void:
	if $"/root/Global".vidas == 0:
		get_tree().quit()

func criaAsteroide():
	var asterix = asteroide.instantiate()
	get_tree().get_root().add_child(asterix)

func _on_tempo_timeout() -> void:
	criaAsteroide()
