#COMRAD TANK
extends CharacterBody2D

var bullet = preload("res://Scenes/missel.tscn")

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta
		
	if $colidePlayer.is_colliding(): 
		$TimerTiro.start()
		$colidePlayer.enabled = false
		
func atirar():
	var vBullet = bullet.instantiate()
	vBullet.global_position.x = self.global_position.x - 15
	vBullet.global_position.y = self.global_position.y + 5
	get_tree().get_root().add_child(vBullet)


func _on_timer_tiro_timeout() -> void:
	$TimerTiro.stop()
	atirar()
	$colidePlayer.enabled = true
