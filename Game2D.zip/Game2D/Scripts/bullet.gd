extends Area2D

var velocidade = 400

func _ready() -> void:
	pass # Replace with function body.

func _process(delta: float) -> void:
	move_local_y(-delta * velocidade)
