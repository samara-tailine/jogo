#COINS
extends Area2D

func _ready() -> void:
	pass 

func _process(delta: float) -> void:
	pass

func _on_body_entered(body: Node2D) -> void: #se player entra em contato com a moeda e aumenta o player
	if body.name == "Player":
		$Animacao.animation = "coletada"
		body.scale *= 1.5
		$CollisionShape2D.set_deferred("disabled", true)
		await get_tree().create_timer(6).timeout
		body.scale = Vector2(1,1)
		queue_free()

func _on_animacao_animation_finished() -> void: 
	pass
