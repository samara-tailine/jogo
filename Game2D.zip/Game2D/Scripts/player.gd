#PLAYER
extends CharacterBody2D

const SPEED = 100.0
const JUMP_VELOCITY = -375.0

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Handle jump.
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var direction := Input.get_axis("ui_left", "ui_right")
	
	if direction and $"/root/Global".onion == 0:
		velocity.x = direction * SPEED
		$animacao.scale.x = direction
	else:
		if $"/root/Global".onion == 1:
			await get_tree().create_timer(2.0).timeout
			$"/root/Global".onion = 0
			
		velocity.x = move_toward(velocity.x, 0, SPEED)
		
	setAnimation(direction)
	move_and_slide()
	
func setAnimation(valor):
	if valor != 0:
		$animacao.animation = "Run"
	if valor == 0:
		$animacao.animation = "Idle"


func receber_dano(quantidade: int = 1) -> void: #dano jogador
	Global.vidasPlayer -= quantidade #tira uma vida
	
	if Global.vidasPlayer <= 0:
		get_tree().change_scene_to_file("res://Scenes/game_over.tscn") #vai para cena gameover
	else:
		get_tree().reload_current_scene() #reinicia a fase

func _on_fail_zone_1_body_entered(body: Node2D) -> void:  #dá dano na failzone 
	if body.name == "Player":
		receber_dano(1) 
