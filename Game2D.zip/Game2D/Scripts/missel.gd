#MISSEL
extends CharacterBody2D

const SPEED = 150.0
var direction = -1

func _physics_process(delta: float) -> void:
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	move_and_slide()

func _on_colisao_body_entered(body: Node2D) -> void:
	if body.name == "Player":
		if body.has_method("receber_dano"):
			body.receber_dano(1) #recebe dano do míssel
		queue_free()

func _on_colisao_area_entered(area: Area2D) -> void:
	queue_free()
