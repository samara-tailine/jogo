#nave
extends Area2D

var velocidade = 100
var bullet = preload("res://Scenes/bullet.tscn")
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	self.global_position.x = 240
	self.global_position.y = 250

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Input.is_action_pressed("esquerda"):
		move_local_x(delta * -velocidade)
	if Input.is_action_pressed("direita"):
		move_local_x(delta * velocidade)
	if Input.is_action_just_pressed("atirar"):
		atirar()

func atirar():
	var vBullet = bullet.instantiate()
	vBullet.global_position.x = self.global_position.x
	vBullet.global_position.y = self.global_position.y - 10
	get_tree().get_root().add_child(vBullet)


func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("Asteroides"):
		area.queue_free()
		$"/root/Global".vidas -= 1
		$"/root/Global".asteroides = 0
		get_tree().reload_current_scene()
