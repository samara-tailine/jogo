extends Area2D

var velocidade = 70

func _ready() -> void:
	randomize()
	self.global_position.y = -20
	self.global_position.x = randi_range(20,460)

func _process(delta: float) -> void:
	move_local_y(delta * velocidade)
	if self.global_position.y >= 300:
		$"/root/Global".vidas -= 1
		self.queue_free()

func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("Bullets"):
		$"/root/Global".asteroides += 1
		area.queue_free()
		queue_free()
