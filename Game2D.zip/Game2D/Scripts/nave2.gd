extends Area2D

var velocidade = 200 # Define a velocidade da nave

func _ready() -> void:
	self.global_position.x = 240 # Define a posição inicial no eixo X
	self.global_position.y = 250 # Define a posição inicial no eixo Y
	# A palavra "self" refere-se ao próprio nó
	
func _process(delta: float) -> void:
	# Condições de movimentação da nave e ação de tiro
	if Input.is_action_pressed("esquerda") or Input.is_action_pressed("A"):
		move_local_x(delta * -velocidade)
	if Input.is_action_pressed("direita") or Input.is_action_pressed("D"):
		move_local_x(delta * velocidade)
	if Input.is_action_just_pressed("atirar"):
		pass
