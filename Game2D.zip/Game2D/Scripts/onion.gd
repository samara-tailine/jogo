#ONION
extends CharacterBody2D

var SPEED = 30.0
var direction = -1

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta
		
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	if $colisaoCenario.is_colliding():
		direction *= -1
		self.scale.x *= -1
	
	if $colidePlayer.is_colliding():
		$"/root/Global".onion = 1
		self.queue_free()

	move_and_slide()
