extends Node2D

func _ready() -> void:
	pass # Replace with function body.

func _process(delta: float) -> void:
	exibeVidas()

func exibeVidas():
	if $"/root/Global".vidasPlayer == 3:
		$HUD/Vida1.visible = true
		$HUD/Vida2.visible = true
		$HUD/Vida3.visible = true
		
	if $"/root/Global".vidasPlayer == 2:
		$HUD/Vida1.visible = true
		$HUD/Vida2.visible = true
		$HUD/Vida3.visible = false
	
	if $"/root/Global".vidasPlayer == 1:
		$HUD/Vida1.visible = true
		$HUD/Vida2.visible = false
		$HUD/Vida3.visible = false
		
	if $"/root/Global".vidasPlayer < 1:
		get_tree().quit()
