#OCTI
extends CharacterBody2D

var SPEED = 30.0
var direction = -1

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta
	
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	if $colisaoCenario.is_colliding():
		direction *= -1
		self.scale.x *= -1
		
	if $colidePlayer.is_colliding():
		SPEED = 70 
	else:
		SPEED = 30
		
	move_and_slide()


func _on_hurt_body_entered(body: Node2D) -> void:
	if body.name == "Player":
		body.velocity.y = -400
		$Animacao.animation = "Hurt"
		SPEED = 0
		direction = 0
		await get_tree().create_timer(1.0).timeout
		self.queue_free()
		
